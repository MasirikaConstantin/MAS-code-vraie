<?php $__env->startSection('section','Modifier Votre commentaire'); ?>
<?php $__env->startSection('contenus'); ?>
<?php
                      $class=null;
                            if($comment->post->categorie_id==1){
                                $class='language-csv';
                            }
                            elseif($comment->post->categorie_id==2){
                                $class='language-css';
                            }
                            elseif($comment->post->categorie_id==3){
                                $class='language-php' ;
                            }
                            elseif($comment->post->categorie_id==4){
                                $class='language-javascript';
                            }
                            elseif($comment->post->categorie_id==5){
                                $class='language-python';
                            }
                            elseif($comment->post->categorie_id==6){
                                $class='language-java';
                            }
                            //endif
                      ?>
<section class="bg-gray-800 py-8 antialiased dark:bg-gray-900 md:py-16">
<ul class="list-none space-y-4">

    <?php if(session('success')): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-md shadow-md">
      <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <div class="w-full h-0.5 bg-gray-200 my-6 rounded-md"></div>

    <li class="shadow-lg rounded-lg p-6 border-t border-gray-300 space-y-4">
        <a id="exemple" class="d-block text-gray-700 hover:text-gray-900 transition-colors" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
            <button type="button" class="rounded-full shadow-md p-1 transition-transform transform hover:scale-105" data-bs-toggle="modal" data-bs-target="#exampleModal">
                <img src="<?php echo e(Auth::user()->imageUrls()); ?>" alt="User Avatar" width="50" height="50" class="rounded-full">
            </button>
        </a>
        
        <p class="mt-4 text-lg font-semibold"><?php echo e($comment->contenus); ?></p>

        <?php if($comment->codesource): ?>
        <pre class="border border-gray-300 bg-gray-50 p-4 mt-5 rounded-md shadow-inner overflow-x-auto">
            <code class="<?php echo e($class); ?>"><?php echo e($comment->codesource); ?></code>
        </pre>
        <?php endif; ?>

        <hr class="my-4 border-gray-200">

        <p class="text-sm text-gray-500">Publié le : <?php echo e($comment->updated_at->formatLocalized('%d %B %Y')); ?></p>
    </li>

</ul>

<form method="post" class="mt-10 bg-gray-800 space-y-6">
    <?php echo csrf_field(); ?>
    <div class="flex bg-gray-200 flex-col md:flex-row space-y-6 md:space-y-0 md:space-x-6 bg-gray-100 p-6 rounded-lg shadow-md">
        
        <div class="flex-1 bg-gray-200 ">
            <label for="exampleFormControlTextarea1" class="block text-center font-medium text-gray-700 mb-2">Votre Message</label>
            <?php $__errorArgs = ["contenus"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded-md mb-2">
              <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <textarea class="w-full p-4 bg-gray-200 text-gray-800 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:border-indigo-500" name="contenus" id="exampleFormControlTextarea1" rows="5"><?php echo e($comment->contenus); ?></textarea>
        </div>

        <div class="flex-1">
            <label for="exampleFormControlTextarea2" class="block text-center font-medium text-gray-700 mb-2">Code Source (si possible)</label>
            <?php $__errorArgs = ["codesource"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded-md mb-2">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <textarea class="w-full p-4 bg-gray-200 border text-gray-800 border-gray-300 rounded-lg shadow-sm focus:outline-none focus:border-indigo-500" name="codesource" id="exampleFormControlTextarea2" rows="5"><?php echo e($comment->codesource); ?></textarea>
        </div>

    </div>

    <div class="text-center">
        <button type="submit" class="bg-indigo-600 text-white px-6 py-3 rounded-lg shadow-md transition-transform transform hover:scale-105 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500">
            Mettre à jour
        </button>
    </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/masirika-constantin/Vidéos/Mas-Code/resources/views/modifcomm.blade.php ENDPATH**/ ?>